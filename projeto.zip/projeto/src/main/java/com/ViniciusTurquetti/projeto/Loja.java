package com.ViniciusTurquetti.projeto;

public interface Loja {
    public Double getValorTotal();
}
